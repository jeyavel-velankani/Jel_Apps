class Project < ActiveRecord::Base
  belongs_to :employee
end
