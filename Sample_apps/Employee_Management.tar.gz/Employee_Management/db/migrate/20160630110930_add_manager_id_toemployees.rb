class AddManagerIdToEmployees < ActiveRecord::Migration
  def change
  end
end
